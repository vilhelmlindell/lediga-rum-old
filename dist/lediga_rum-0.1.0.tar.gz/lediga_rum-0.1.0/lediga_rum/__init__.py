import time
from room_info import save_room_info

start_time = time.time()
save_room_info()
end_time = time.time()
elapsed_time = end_time - start_time
print(f"Function took {elapsed_time} seconds to execute.")
